# Solar Oracle Walkman — 最新工作版 R18d

R18d 位於 `_R18d_work/`，按現行charge-adg706 PCB的K1座標與背面旋轉，新增精準局部避空。K1下方約12.0×9.8mm、R1內凹0.6mm，名義淨空0.42→1.02mm，保留1.4mm底厚。四個PCB孔與八個K1焊盤核對，且輸出STL的避空位置與底厚另作實測驗證。

**最新廠商列印包：`_R18d_work/R18d_STL.zip`**，只有三個ASCII STL，匯入mm、各一件、1:1。原生CAD為`SolarOracle_R18d.FCStd`；對位圖`R18d_K1_MAPPING.svg`，說明`README_R18d.md`，驗證`mechanical_QA.json`、`export_QA.json`與`PACKAGE_QA.json`。本次沒有渲染。實際焊接抬高與SLA尺寸仍需樣件確認。

Blender新版已補齊：`_R18d_work/SolarOracle_R18d.blend`，同步新下殼及實際K1模型，frame1／30／60為閉合／拿開艙門／垂直提起玻璃。檔案已重新開啟驗證，K1網格至避空底面約1.02mm；未進行圖片渲染，STL ZIP維持原驗證檔。

## 歷史 R18c — 尚未加入K1局部避空

R18c 位於 `_R18c_work/`：移除上方兩條矽膠保護墊，兩條壓腳改為全高等寬3.2×50mm的平底實體、底面Z4.3直接接觸玻璃，無原先兩階階梯。每條CAD名義接觸面160mm²，比R18b的110mm²增加45.45%；斑馬條名義壓縮0.3mm（約10%）。實際磁吸力、壓腳平面度及導通待樣件確認。

請開 `_R18c_work/SolarOracle_R18c.blend` 或 `SolarOracle_R18c.FCStd`；廠商包為 `SolarOracle_R18c_SUPPLIER_PROTOTYPE.zip`，三件毫米3MF與單件STEP。接觸區與平底腳圖見 `_R18c_work/review/`，完整說明見 `_R18c_work/README_R18c.md`。上下殼幾何與R18b精確相同，保留完整M3孔、平整凹座、R16按鈕及可拆磁吸艙門。

## 歷史 R18b — 含上方軟墊／階梯壓腳版本

R18b 改為**可拆磁吸艙門、DSSC上方垂直置入**，位於 `_R18b_work/`，先讀 `_R18b_work/README_R18b.md`。請開 `SolarOracle_R18b.blend` 或 `SolarOracle_R18b.FCStd`；艙門移除參考為 `SolarOracle_R18b_HATCH_REMOVED.FCStd`。最新廠商包：`SolarOracle_R18b_SUPPLIER_PROTOTYPE.zip`，只含三件可印幾何的3MF與單件STEP量測參考。

取消側插口、下方拾取承托、四個金屬導銷及凸耳，重建平整凹座與完整圓形M3讓位孔，恢復R16一體式按鈕。前方螺絲承靠固定殼，艙門可越過螺絲頭直接提起；使用頭徑≤5.5、頭高≤2mm的低頭M3×20。保留單邊0.2mm配合、16顆Ø5×2.7mm磁鐵、主體24.6mm及電容區29.6mm。數位檢查通過，實際磁力、導通及SLA配合仍需樣件確認；摘要見 `_R18b_work/FINAL_SUMMARY.json`。

## 歷史 R18 — 側插／導銷版，非現行列印來源

R18 磁吸微升／側插 DSSC prototype 位於 `_R18_work/`，先讀 `_R18_work/README_R18.md`。原生 CAD：`SolarOracle_R18.FCStd`；開艙參考：`SolarOracle_R18_OPEN_REVIEW.FCStd`。廠商包：`SolarOracle_R18_SUPPLIER_PROTOTYPE.zip`，內含四件毫米 3MF 與獨立 STEP 量測參考；不要列印組裝中的電子元件。

R18 採單邊0.2 mm配合、16顆Ø5×2.7 mm磁鐵、四個防脫微升槽、側向換玻璃、側按搖臂、完整USB凹艙及局部電容鼓包。主體24.6 mm，電容區29.6 mm；上下窗口距玻璃外表面各10.7 mm。數位檢查摘要見 `_R18_work/FINAL_SUMMARY.json`；實際磁力、接觸電阻及SLA列印配合仍待實物確認。R17保留為歷史審查版。

## 歷史 R6 記錄（以下交付資訊不是 R18b 現行廠商包）

### Solar Oracle Walkman 共用機殼 R6 — e-paper 透明頂蓋

廠商樣件列印／尺寸審查唯一 ZIP：SolarOracle_R6_完整共用機殼_ePaper透明頂蓋_廠商樣件_1比1mm.zip（Telegram 文件 13884）。R4 的 13830 已撤回：e-paper 上方缺少實際連續頂蓋；不要列印或與 R6 混用。內含三件主殼 3MF、三件替代 STL、三件 STEP 量測參考與說明；**只選一套 3MF 或 STL 匯入，不能全選九件**。沒有渲染專用 Voronoi 染色 DSSC，也沒有老版獨立推桿/C扣。

原生 FreeCAD：_R6_work/SolarOracle_Common_R6_display_roof.FCStd；3MF／STL／STEP 單件見 _R6_work/。新增一體式 68 × 44.5 × 1.5 mm e-paper 頂蓋，距名義 e-paper 最高點 0.8 mm；透明度、橋接品質與實物間隙需樣件驗證。下殼與 DSSC 壓框與 R4 檔案位元相同。R6 繼承的一體式按臂觸及名義 SW1 上表面；六個膠黏六角 M3 槽對邊5.7mm，為手邊5.5mm對邊螺帽留名義0.1mm單側空間。透明前壓框與外擴背窗均為實際幾何開孔，開放設計不防塵防水。raw/charge 兩版板厚1.6mm且孔位保持原樣；e-paper高度11.5、ESP32高度9mm（以PCB上表面為準）。

review/ 內既有 R4/R5 自然光圖及 Blender 尚未同步 R6 頂蓋，勿據此判斷廠商列印幾何；Voronoi 酒紅/SQ2藍綠 W 為視覺素材，不屬於列印檔。審圖與數位網格檢查不等於實物壽命驗證；廠商/使用者需用實際螺帽、螺絲與材料核對印件配合、按臂疲勞及 DSSC 玻璃壓力。R1/R2 歷史輸出位於專案 _archive/，勿混用。

## 歷史 R5 增強光照樣件候選（已被 R6 單一廠商包取代，勿混用）
SolarOracle_R5_增強光照_完整共用機殼_廠商樣件檢查_1比1mm.zip 含三件共用機殼，單位 mm。下殼與上殼和 R4 幾何相同；DSSC 壓框四側內緣為斜削避光，兩側 M3 座與外側高度不變。前後有效區邊緣幾何起始遮蔽角由約32°提升至約42°；窗內緣薄處約0.4mm、旁有局部補強，須以實物列印確認耐碰與玻璃壓持。此候選與 R4 13830 均已被 R6 13884 取代。
