"""R19 two-piece mechanical prototype. Run with FreeCAD's bundled Python.

--bootstrap copies read-only PCB/model evidence; subsequent builds are local.
All dimensions are mm in PCB coordinates. This is not an electrical review.
"""
import argparse,hashlib,json,math,shutil,sys,tempfile,zipfile
from pathlib import Path
import FreeCAD as A
import Part

ROOT=Path(__file__).resolve().parents[1]
V=A.Vector
def write(p,d):
 p=ROOT/p;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
def read(p):return json.loads((ROOT/p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def box(x,y,z,w,h,t):return Part.makeBox(w,h,t,V(x,y,z))
def cyl(x,y,z,r,h):return Part.makeCylinder(r,h,V(x,y,z))
def fuse(ss):return ss[0].multiFuse(ss[1:]).removeSplitter() if len(ss)>1 else ss[0]
def rr(x,y,z,w,h,t,r):
 return fuse([box(x+r,y,z,w-2*r,h,t),box(x,y+r,z,w,h-2*r,t)]+[cyl(a,b,z,r,t) for a in [x+r,x+w-r] for b in [y+r,y+h-r]])
def bounds(s):
 b=s.BoundBox;return [b.XMin,b.XMax,b.YMin,b.YMax,b.ZMin,b.ZMax]
def moved(s,x=0,y=0,z=0,angle=0):
 s=s.copy()
 if angle:s.rotate(V(0,0,0),V(1,0,0),-angle)
 s.translate(V(x,y,z));return s
def overlap(a,b):
 if not a.BoundBox.intersect(b.BoundBox):return 0.
 return a.common(b).Volume
def bootstrap():
 project=ROOT.parents[2];old=ROOT.parent/'R18'
 variant='raw' if ROOT.name.endswith('_RAW') else 'charge-adg706'
 sys.path.insert(0,'/Users/shihweichieh/.config/opencode/skills/kicad/scripts')
 from sexp_parser import parse_file,find_all,find_first,get_property,get_value
 src=ROOT/'sources';src.mkdir(exist_ok=True)
 pcb=project/f'hardware/solar-oracle-walkman-{variant}/KiCad/Marc_USB.kicad_pcb'
 shutil.copy2(pcb,src/'PCB.kicad_pcb')
 tree=parse_file(str(pcb));fps=[]
 models=src/'models';models.mkdir(exist_ok=True)
 lib=Path('/Applications/KiCad/KiCad.app/Contents/SharedSupport/3dmodels')
 for fp in find_all(tree,'footprint'):
  ref=get_property(fp,'Reference');at=list(map(float,find_first(fp,'at')[1:]));at+= [0]*(3-len(at))
  rec={'ref':ref,'at':at,'layer':get_value(fp,'layer'),'footprint':fp[1],'models':find_all(fp,'model'),'pads':[]}
  for p in find_all(fp,'pad'):
   pa=find_first(p,'at');dr=find_first(p,'drill');sz=find_first(p,'size')
   rec['pads'].append({'number':p[1],'kind':p[2],'shape':p[3],'at':list(map(float,pa[1:3])),
    'size':list(map(float,sz[1:3])),'drill':float(dr[1]) if dr and dr[1]!='oval' else None})
  if rec['models'] and 'KICAD' in rec['models'][0][1]:
   rel=rec['models'][0][1].split('}/',1)[1];target=models/Path(rel).name
   if (lib/rel).is_file():
    shutil.copy2(lib/rel,target);rec['model_file']='sources/models/'+target.name
   else:rec['missing_library_model']=str(lib/rel)
  elif ref=='K1':
   k=project/'hardware/solar-oracle-walkman-K1/models/Relay_DPDT_Omron_G6K-2F-Y.step'
   shutil.copy2(k,models/k.name);rec['model_file']='sources/models/'+k.name
  fps.append(rec)
 edges=[]
 for e in tree:
  if isinstance(e,list) and e and e[0] in ['gr_line','gr_arc'] and get_value(e,'layer')=='Edge.Cuts':
   edges.append({'kind':e[0],**{p:list(map(float,find_first(e,p)[1:3])) for p in (['start','end'] if e[0]=='gr_line' else ['start','mid','end'])}})
 write('sources/pcb_geometry.json',{'origin':[111.075,29.275],'thickness':1.6,'footprints':fps,'edges':edges,'variant':variant,'live_source':str(pcb),'PCB_sha256':sha(pcb)})
 names=['Epaper_module', 'ESP32_raw_module' if variant=='raw' else 'ESP32_module']
 if variant!='raw':names+=['Supercap_10_5','Supercap_67_45']
 with zipfile.ZipFile(old/'sources/geometry_sources.zip') as z:
  for n in names+['R16_button_functional_region']:
   (src/(n+'.brep')).write_bytes(z.read(n+'.brep'))
 # Named module subparts distinguish the USB shell from protruding contacts.
 shutil.copy2(old/'sources/visual/s3_detailed.json',src/'s3_detailed.json')
 shutil.copy2(old/'history/pre_consolidation_status.md',src/'module_height_history.md')
 write('parameters.json',{'revision':ROOT.name,'variant':variant,'fit_per_side':.2,'PCB_thickness':1.6,
  'glass_centre_x':37.9,'glass_centre_y':-33,'upper_glass_widths':[66,70],'glass_length':60,'glass_thickness_each':1.6,
  'zebra_free':3.,'zebra_loaded':2.7,'pressure_bottom':4.3,'pressure_width':3.2,'pressure_length':50,
  'outer_main_xy':[-3,-134,84,142.4],'corner_radius':4,'roof_z':15,'roof_thickness':2,
  'main_floor_z':-7.2 if variant=='raw' else -9.6,'floor_thickness':2,'wall':2.8,'split_z':3.6,
  'design_revision':'R19_WINDOW_END_ROWS_FREE_GLASS_SEAT',
  'magnet_centres':[[x,y] for y in [1.1,-67.1] for x in [11.9,29.2,46.6,63.9]],
  'magnet_diameter':5,'magnet_thickness':2.7,'magnet_pocket_diameter':5.4,'magnet_boss_radius':3.9,
  'magnet_stop_z':8,'magnet_face_gap':2.05,'front_moving_y':.6,'rear_moving_y':-66.6,
  'PCB_install_angle_deg':0,'PCB_install_rear_offset':71.2,'PCB_install_lift_mm':1.0,
  'rear_frame_under_PCB_clearance':.25,'rear_moving_magnet_to_PCB_clearance':.2,
  'note':'Two printed parts. Nominal 10% compression is geometrical; magnet force, print flatness and electrical resistance require a physical trial.'})
 write('sources/manifest.json',{str(p.relative_to(ROOT)):sha(p) for p in src.rglob('*') if p.is_file() and p.name!='manifest.json'})

def shape_file(p):
 s=Part.Shape();s.read(str(ROOT/p));return s
def pcb_shape(data):
 def v(p):return V(p[0]-111.075,29.275-p[1],0)
 es=[Part.makeLine(v(e['start']),v(e['end'])) if e['kind']=='gr_line' else Part.Arc(v(e['start']),v(e['mid']),v(e['end'])).toShape() for e in data['edges']]
 ws=[Part.Wire(es) for es in Part.sortEdges(es)];ws.sort(key=lambda w:Part.Face(w).Area,reverse=True)
 f=Part.Face(ws[0])
 for w in ws[1:]:f=f.cut(Part.Face(w))
 s=f.extrude(V(0,0,-1.6))
 for fp in data['footprints']:
  a=math.radians(fp['at'][2]);cx,cy=fp['at'][0]-111.075,29.275-fp['at'][1]
  for pad in fp['pads']:
   if pad['drill']:
    px,py=pad['at'];x=cx+px*math.cos(a)+py*math.sin(a);y=cy+px*math.sin(a)-py*math.cos(a)
    s=s.cut(cyl(x,y,-2,pad['drill']/2,3))
 return s.removeSplitter()

def make_refs(data,cfg):
 refs={};evidence={}
 def add(n,s,cat,note):refs[n]=(s,cat);evidence[n]=note
 add('Carrier_board',pcb_shape(data),'Electronics','Current PCB Edge.Cuts, plated/NPTH drills and 1.6mm thickness; no copper routing modeled.')
 for fp in data['footprints']:
  n=fp['ref'];x,y,a=fp['at'];x-=111.075;y=29.275-y
  if n.startswith('H'):continue
  if n=='J1':
   for p in fp['pads']:
    px,py=p['at'];w,h=p['size'];add('DSSC_pad_'+p['number'],box(x+px-w/2,y-py-h/2,-.035,w,h,.035),'Electronics','Actual J1 pad XY from PCB. Finished contact copper is Z0; 35um visual lies inside the total 1.6mm PCB envelope.')
   continue
  if n in ['A1','J3','C201','C202']:
   key={'A1':'ESP32_raw_module' if cfg['variant']=='raw' else 'ESP32_module','J3':'Epaper_module','C201':'Supercap_10_5','C202':'Supercap_67_45'}[n]
   add(key,shape_file('sources/'+key+'.brep'),'Electronics','Frozen detailed reference; current footprint position checked against source registration.')
   continue
  if 'model_file' in fp:
   s=Part.read(str(ROOT/fp['model_file']));back=fp['layer']=='B.Cu'
   rot=A.Rotation(V(0,0,1),a)
   if back:rot=rot.multiply(A.Rotation(V(1,0,0),180))
   z=(-1.6 if n=='K1' else -1.68) if back else .08
   s.Placement=A.Placement(V(x,y,z),rot).multiply(s.Placement)
   add('K1_relay' if n=='K1' else 'PCB_'+n,s,'Electronics','Current PCB placement and standard STEP model; B.Cu uses proper Rx180, no reflection.')
  else:
   # Explicit mechanical envelopes for custom footprints with no declared model.
   dims={'U207':(4,4,1.2),'L203':(4.3,4.3,3.2),'L201':(4.5,4.5,2.2),'L202':(2,1.2,1.2)}
   if n not in dims:raise RuntimeError('Unmodeled component '+n)
   w,h,t=dims[n];s=box(x-w/2,y-h/2,-1.68-t,w,h,t)
   add('Envelope_'+n,s,'Electronics','Conservative envelope, not supplier STEP: '+str(dims[n]))
 cx=cfg['glass_centre_x'];ul=cfg['zebra_loaded'];p=cfg['pressure_bottom']
 add('DSSC_upper_glass_66',box(cx-33,-63,ul,66,60,1.6),'Glass','Default 66mm upper plate; lower plate centred below.')
 add('DSSC_upper_glass_70',box(cx-35,-63,ul,70,60,1.6),'Alternative_glass','Alternative only; not simultaneously installed.')
 add('DSSC_lower_glass',box(cx-30,-63,ul-1.6,60,60,1.6),'Glass','60mm lower plate; .2mm corner-guide clearance.')
 for i,x in enumerate([2.7,68.1]):add('Zebra_'+str(i),box(x,-58,0,5,50,ul),'Zebra','Measured free height 3mm, nominal loaded height 2.7mm; single strip per side.')
 nutbottom=-5.8 if cfg['variant']=='raw' else -6.6
 for i,fp in enumerate(f for f in data['footprints'] if f['ref'].startswith('H')):
  x,y=fp['at'][0]-111.075,29.275-fp['at'][1]
  pts=[V(x+3.17542648*math.cos(math.radians(30+j*60)),y+3.17542648*math.sin(math.radians(30+j*60)),nutbottom) for j in range(6)]
  rear_charge=cfg['variant']!='raw' and y<-100
  nz=-14.4 if rear_charge else nutbottom
  pts=[V(p.x,p.y,nz) for p in pts]
  nut=Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(V(0,0,2.4)).cut(cyl(x,y,nz-1,1.5,5))
  length=14 if rear_charge else 6 if cfg['variant']=='raw' else 8
  screw=fuse([cyl(x,y,-length,1.5,length),cyl(x,y,0,2.75,2)])
  add('PCB_nut_'+fp['ref'],nut,'Hardware','M3 nut AF5.5, thickness2.4; side loaded before screw installation.')
  add('PCB_screw_'+fp['ref'],screw,'Hardware','M3x%d low head, diameter<=5.5 height<=2; fixes PCB only.'%length)
 for i,(x,y) in enumerate(cfg['magnet_centres']):
  front=i<4;fz=5.1 if front else 5.92;uz=9.85 if front else 10.67;uy=.6 if front else -66.6
  add('Magnet_lower_'+str(i),cyl(x,y,fz,2.5,2.7),'Lower_magnets','Window-end fixed magnet. Rear row is below the e-paper PCB, mechanically clear of it.')
  add('Magnet_upper_'+str(i),cyl(x,uy,uz,2.5,2.7),'Upper_magnets','Window-end moving magnet; both rows have the same 2.05mm face gap and mirrored .5mm fore/aft offset.')
 return refs,evidence

def make_parts(data,cfg):
 floor=cfg['main_floor_z'];inside=floor+2
 # Compact rear radii keep a full-thickness straight loading mouth.
 outline=lambda z,t:fuse([rr(-3,-134,z,84,142.4,t,4),rr(-3,-134,z,84,8,t,1.2)])
 # Continuous original-style stepped/rabbet fit, .2mm radial and axial clearance.
 lower=outline(floor,3.6-floor).cut(rr(-.2,-131.2,inside,78.4,136.8,30,1.2))
 # Retain the original R18 1.4mm tongue / 2mm height, with .2mm mating clearance.
 tongue=rr(-1.6,-132.6,3.6,81.2,139.6,2,2.6).cut(rr(-.2,-131.2,3.5,78.4,136.8,2.2,1.2))
 lower=fuse([lower,tongue])
 lower=lower.cut(rr(7.4,-63.5,-20,61,61,20,1))
 if cfg['variant']!='raw':
  # Local pockets include the short angled PCB installation path.
  for x,w in [(.85,19.3),(57.8,19.3)]:
   lower=fuse([lower,rr(x-1,-134,-14.6,w+2,60.1,7,2)])
   lower=fuse([lower,box(x-1,-134,-14.6,w+2,4,7)])
   lower=lower.cut(rr(x,-135,-12.6,w,60.1,15,1))
  lower=lower.cut(rr(19.15,-115.625,-8.2,13.275,9.8,2,1))
 # Rear loading aperture: the whole PCB assembly slides under the fixed glass well.
 entry_floor=-2.7 if cfg['variant']=='raw' else -6.4
 lower=lower.cut(box(-5,-140,entry_floor,90,10.2,30))
 # Fixed PCB compression bearings; they do not touch either glass plate.
 lower=fuse([lower,box(5.1,-58,inside,2.2,50,-1.6-inside),box(69.3,-58,inside,2.2,50,-1.6-inside)])
 # Rear captive-nut entries need solid corner webs, not a thin remnant of the rounded cavity.
 if cfg['variant']=='raw':
  lower=fuse([lower,box(-.2,-131.2,inside,7.5,8.4,-1.6-inside),box(70.7,-131.2,inside,7.5,8.4,-1.6-inside)])
 else:
  # Edge bearings stay outside the capacitor insertion lanes.
  lower=fuse([lower,box(-.2,-131.2,-12.6,1.8,8.4,11),box(76.3,-131.2,-12.6,1.9,8.4,11)])
 nutbottom=-5.8 if cfg['variant']=='raw' else -6.6
 mounts=[]
 for fp in data['footprints']:
  if not fp['ref'].startswith('H'):continue
  x,y=fp['at'][0]-111.075,29.275-fp['at'][1];mounts.append([x,y])
  if cfg['variant']!='raw' and y<-100:
   # Recessed underside nut; no tall printed boss obstructs a populated capacitor.
   lower=fuse([lower,cyl(x,y,-14.6,4.5,3.6)])
   pts=[V(x+3.40636659*math.cos(math.radians(30+j*60)),y+3.40636659*math.sin(math.radians(30+j*60)),-14.6) for j in range(6)]
   pocket=Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(V(0,0,2.6))
   lower=lower.cut(pocket).cut(cyl(x,y,-14.7,1.7,15));continue
  lower=fuse([lower,cyl(x,y,inside,4.5,-1.6-inside)])
  pts=[V(x+3.40636659*math.cos(math.radians(30+j*60)),y+3.40636659*math.sin(math.radians(30+j*60)),nutbottom-.2) for j in range(6)]
  pocket=Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(V(0,0,2.8))
  entrance=box(-12 if x<39 else x,y-2.95,nutbottom-.2,x+12 if x<39 else 100-x,5.9,2.8)
  lower=lower.cut(fuse([pocket,entrance,cyl(x,y,-6.2 if cfg['variant']=='raw' else -8.2,1.7,11)]))
 # Open-bottom four-sided well: side guides only, never a support under the glass.
 well=box(1.3,-64.6,1.4,73.2,63.2,3.8).cut(box(2.7,-63.2,1.3,70.4,60.4,4))
 for x in [6.3,68.1]:
  for y in [-63.2,-7.8]:well=fuse([well,box(x,y,1.4,1.4,5,1.1)])
 # Allow lateral rubber expansion independently of the 70.4mm upper-glass throat.
 well=well.cut(box(2.5,-58.2,1.3,.2,50.4,1.9)).cut(box(73.1,-58.2,1.3,.2,50.4,1.9))
 for x,y in mounts:well=well.cut(cyl(x,y,1.3,2.95,5))
 # Open screw-access corners instead of leaving thin crescents around circular holes.
 well=well.cut(box(1.2,-6.2,1.3,4.9,4.9,4)).cut(box(71.9,-6.2,1.3,2.7,4.9,4))
 lower=fuse([lower,well])
 for yy in [-15,-33,-51]:
  lower=fuse([lower,box(-.3,yy-.7,1.4,1.7,1.4,1.4),box(74.4,yy-.7,1.4,3.9,1.4,1.4)])
 upper=outline(3.8,11.2).cut(rr(-.2,-131.2,3.7,78.4,136.8,9.3,1.2))
 upper=upper.cut(rr(-1.8,-132.8,3.7,81.6,140,2.1,2.8))
 # The removable whole lid also closes the rear PCB loading aperture.
 ez=entry_floor+.2
 skirt=outline(ez,3.8-ez).cut(box(-.4,-131.7,ez-.1,78.8,150,4-ez))
 skirt=skirt.common(box(-5,-140,ez,90,10,4-ez))
 if cfg['variant']=='raw':
  for x,y in mounts:
   if y<-100:skirt=skirt.cut(cyl(x,y,ez-.1,4.7,1.3-ez))
 upper=fuse([upper,skirt])
 if cfg['variant']!='raw':
  for x,w in [(.85,19.3),(57.8,19.3)]:
   rear=box(x+.2,-134,-12.4,w-.4,2.3,ez+12.4)
   upper=fuse([upper,rear])
 # Top optical opening and full-length, unstepped pressure feet.
 upper=upper.cut(box(10.7,-60.2,2.6,54.4,54.4,20))
 upper=fuse([upper,box(5.2,-58,4.3,3.2,50,8.7),box(67.4,-58,4.3,3.2,50,8.7)])
 # Rear fixed bridge passes BELOW the e-paper PCB; the moving magnets are ABOVE it.
 # The PCB is not a mechanical stop and is not clamped between the printed parts.
 lower=fuse([lower,box(6,-70.98,3.85,65.4,7.76,4.77)])
 for postx,stemx,armx,armw in [(6,-1.8,-1.8,9.2),(70,78.2,70,9.8)]:
  lower=fuse([lower,box(postx,-70.98,8.62,1.4,7.76,2.38),
   box(armx,-70.98,6,armw,7.76,5),box(stemx,-70.98,6,1.6,12.98,5),
   box(stemx,-61.225,3.5,1.6,3.225,7.5)])
  upper=upper.cut(box(stemx-.2,-71.18,3.7,2,13.38,7.3))
  upper=upper.cut(box(armx-.2,-71.18,5.8,armw+.4,7.96,5.4))
 # Explicit upper/lower side-stop contact pads outside the e-paper envelope.
 for xx in [-1.8,78.2]:upper=fuse([upper,box(xx,-61.225,11,1.6,3.225,2.1)])
 # Front stators are ahead of the PCB; the shallow rear overhang stays >=1.4mm above it.
 for x,y in cfg['magnet_centres'][:4]:
  lower=fuse([lower,cyl(x,y,1.4,3.9,6.6),box(x-3.9,.2,floor,7.8,8.2,8-floor)])
  lower=lower.cut(cyl(x,y,5,2.7,3.1))
  upper=upper.cut(cyl(x,y,1.2,4.1,6.8)).cut(box(x-4.1,0,3.7,8.2,8.6,4.3))
  upper=fuse([upper,cyl(x,.6,8,3.7,7)]).cut(cyl(x,.6,7.9,2.7,4.75))
 for x,y in cfg['magnet_centres'][4:]:
  lower=lower.cut(cyl(x,y,5.72,2.7,3))
  upper=fuse([upper,cyl(x,-66.6,10.67,3.7,4.33)]).cut(cyl(x,-66.6,10.57,2.7,2.9))
 # Exact R16 integral flexure, cap, plunger and stop, not a separate printed button.
 crop=box(9.5,-117.8,1.7,7.3,19.6,13.4)
 upper=upper.cut(crop).fuse(shape_file('sources/R16_button_functional_region.brep'))
 raw=cfg['variant']=='raw';face=62.57 if raw else 61.17;cy=-116.385 if raw else -116.335
 # Contacts protrude .38mm beyond the shell: keep .2mm clearance while lifting the whole lid.
 back=63.15 if raw else 61.75
 # USB U-well: the actual shell face determines its end wall, never the PCB/contact XMax.
 upper=upper.cut(box(back,cy-8,3.6,30,16,20))
 cup=fuse([box(back,cy-9.4,2.2,1.4,18.8,12.8),box(back,cy-9.4,2.2,81-back,1.4,12.8),
  box(back,cy+8,2.2,81-back,1.4,12.8),box(back,cy-9.4,2.2,81-back,18.8,1.4)])
 cup=cup.cut(box(back-.1,cy-5.2,3.77,1.6,10.4,6.2))
 upper=fuse([upper,cup])
 # Remove the original outside wall within the open U mouth.
 upper=upper.cut(box(back+1.4,cy-8,3.6,30,16,20))
 lower=lower.cut(box(78,cy-9.6,2,10,19.2,10))
 if not raw:
  # Complete switch body/lever envelope is kept clear, including the rear glass-cage corner.
  swclear=box(73.1,-70.5,-3,20,9.275,8)
  lower=lower.cut(box(73.1,-70.5,-3,20,9.275,9));upper=upper.cut(swclear)
  # Temporary straight feed path for the already-populated side actuator.
  lower=lower.cut(box(78,-134.1,2.4,10,72.875,3.6))
  skirt=outline(2.6,1.2).common(box(78.2,-134.1,2.6,3,63.6,1.2))
  upper=fuse([upper,skirt])
  upper=upper.cut(box(78,-71.18,-20,2,13.38,31))
  upper=upper.cut(box(back+1.4,cy-8,3.6,30,16,20))
  upper=upper.cut(box(back-.1,cy-5.2,3.77,1.6,10.4,6.2))
 lower=lower.removeSplitter();upper=upper.removeSplitter()
 return {'Lower_shell':lower,'Upper_cover':upper},{'USB_shell_face_x':face,'USB_wall_inner_x':back,'USB_centre_y':cy,
  'mounts':mounts,'nut_bottom_z':nutbottom,'K1_relief_floor_z':-8.2 if not raw else None,
  'window_magnets':'Four front pairs and four rear pairs; no side ears',
  'front_magnet_face_gap':2.05,'rear_magnet_face_gap':2.05,'opposed_pair_y_offset':.5,
  'glass_well':'Open bottom; no lower window ledge or glass support shelf',
  'PCB_loading':'Rear horizontal feed at Z+1mm, then lower onto 1.6mm PCB bearings'}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--bootstrap',action='store_true');args=ap.parse_args()
 if args.bootstrap:bootstrap()
 for p,h in read('sources/manifest.json').items():assert sha(ROOT/p)==h,p
 data=read('sources/pcb_geometry.json');cfg=read('parameters.json')
 refs,evidence=make_refs(data,cfg)
 print('REFERENCES',len(refs),flush=True)
 parts,mapping=make_parts(data,cfg)
 doc=A.newDocument(ROOT.name);groups={}
 for name,(s,cat) in dict(refs,**{n:(s,'Printed') for n,s in parts.items()}).items():
  ob=doc.addObject('PartDesign::Feature',name);ob.Shape=s
  ob.addProperty('App::PropertyString','Category').Category=cat
  ob.addProperty('App::PropertyString','Evidence').Evidence=evidence.get(name,'R19 two-piece analytical CAD built from local parameters.')
  if cat not in groups:groups[cat]=doc.addObject('App::DocumentObjectGroup',cat)
  groups[cat].addObject(ob)
  if cat=='Alternative_glass':ob.Visibility=False
 report={'parts':{n:{'valid':s.isValid(),'solids':len(s.Solids),'volume_mm3':s.Volume,'bounds':bounds(s)} for n,s in parts.items()},'mapping':mapping}
 write('qa/build.json',report)
 for n,s in parts.items():
  if len(s.Solids)!=1:print('SOLID_COMPONENTS',n,[(ss.Volume,bounds(ss)) for ss in s.Solids],flush=True)
 assert all(v['valid'] and v['solids']==1 for v in report['parts'].values()),report
 doc.recompute()
 with tempfile.TemporaryDirectory(dir=ROOT) as td:
  p=Path(td)/(ROOT.name+'.FCStd');doc.saveAs(str(p));p.replace(ROOT/p.name)
 print('BUILD_PASS',ROOT.name,report,flush=True)

if __name__=='__main__':main()
