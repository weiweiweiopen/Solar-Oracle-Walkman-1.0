"""Audit and document the corrected narrow, window-end magnetic revision."""
import zipfile
from pathlib import Path
from build import ROOT,read,write,sha
c=read('parameters.json');raw=c['variant']=='raw';name=ROOT.name
qa={n:read('qa/'+n+'.json') for n in ['build','assembly','PCB_installation','thickness','export','blender','blender_saved']}
for n in ['assembly','PCB_installation','thickness','export','blender','blender_saved']:assert qa[n]['pass'],n
assert qa['PCB_installation']['continuous_motion_proven']
assert qa['export']['CAD_sha256']==sha(ROOT/(name+'.FCStd'))==qa['blender']['CAD_sha256']
for p,h in read('sources/manifest.json').items():assert sha(ROOT/p)==h,p
data=read('sources/pcb_geometry.json');live=Path(data['live_source'])
live_match=sha(live)==data['PCB_sha256'] if live.exists() else None
assert live_match is not False
assert qa['assembly']['checks']['no_glass_shelf'] and qa['assembly']['checks']['free_FTO_contacts_both_zebras']
assert qa['assembly']['checks']['same_front_rear_magnet_gap']
for n,r in qa['build']['parts'].items():assert abs(qa['export']['parts'][n]['CAD_volume_mm3']-r['volume_mm3'])<1e-6
with zipfile.ZipFile(ROOT/(name+'_STL.zip')) as z:assert len(z.namelist())==2 and z.testzip() is None
proxies=[f['ref'] for f in data['footprints'] if f['ref'] not in ['H1','H2','H3','H4','J1','A1','J3','C201','C202'] and 'model_file' not in f]
q=qa['assembly'];q['trust_summary']['limits']=[s for s in q['trust_summary']['limits'] if 'custom/missing' not in s]
if proxies:q['trust_summary']['limits'].append('Explicit conservative envelopes: '+', '.join(proxies))
write('qa/assembly.json',q)
text=f'''# {name} — 窗口上下橫排磁吸／自由落座修正版

## 本版識別

`R19_WINDOW_END_ROWS_FREE_GLASS_SEAT`。{'charge-adg706 電容版，含K1。' if not raw else 'raw普通版，無電容鼓包、K1或JP201。'}

- **上下蓋兩個列印件，整片上蓋可垂直取下。**
- **窗口上、下各四組磁鐵，整體84mm寬，沒有側凸磁鐵耳。**
- **取消下窗口高起內緣的玻璃承靠。** 下蓋玻璃艙槽是開底側向定位，玻璃下方不設落座階梯。
- PCB總厚按**1.6mm**；FTO先自然接觸斑馬條，閉蓋後兩條長壓腳才施壓。
- 舊側耳版已否決；其參數、工具及列印包封存於`history/R19_SIDE_EARS_REJECTED.zip`。

## 交付檔案

| 用途 | 檔案 |
|---|---|
| 原生實體組裝 | `{name}.FCStd` |
| 有燈光與SLA半透明材質的檢視場景 | `{name}.blend` |
| 廠商列印包 | `{name}_STL.zip`：只有上下蓋兩個ASCII STL，各一件，mm／1:1 |
| 單件與組裝STEP | `STEP/`，保持PCB座標 |
| 列印姿態STL | `STL_mm/`，上蓋已翻面；SLA支撐與列印傾角由工廠安排 |
| 審圖預覽 | `review/assembly_preview.png`（若執行預覽輸出） |

## 窄外形與磁鐵配置

| 項目 | 本版 |
|---|---|
| 全外形寬×長 | **84×142.4mm** |
| 主體厚／最大厚 | {'22.2／22.2' if raw else '24.6／29.6'}mm |
| 外頂面 | Z15，保持平頂 |
| 磁鐵 | Ø5×2.7mm，共16顆／8組對吸 |
| 四個X位置 | 11.9、29.2、46.6、63.9，對稱於玻璃中心X37.9 |
| 上排／前端 | 固定端Y1.1、上蓋端Y0.6 |
| 下排／後端 | 固定端Y−67.1、上蓋端Y−66.6 |
| 每對磁鐵面距 | **兩排均2.05mm**；各鏡像錯位0.5mm |

下排固定磁鐵位於e-paper前緣PCB下方，上蓋磁鐵位於該PCB上方。固定橋與該PCB底面名義間隙0.25mm，上蓋磁鐵座與PCB頂面間隙0.2mm；**PCB不作壓合止擋，也不被列印件夾住**。磁力穿過PCB的前緣區，磁鐵座避開e-paper顯示玻璃。

為使上下排磁路幾何一致，上排也採2.05mm磁距與反向0.5mm錯位。**這比舊版0.4mm磁距大，吸力會改變；目前沒有磁鐵牌號、拉力或斑馬條反力實測，不能把幾何對稱寫成已實測均壓。** 本版用現有磁鐵試裝確認能否保持閉合與接觸。

## 玻璃、斑馬條與剖面

- 上片：**66×60×1.6或70×60×1.6mm**；下片：置中60×60×1.6mm。
- 上片側向艙槽70.4×60.4mm；66mm玻璃由60mm下片的四角定位導正，不靠加寬上片槽自行找中心。
- 玻璃組中心X37.9／Y−33；向左1.1mm避開JP201，沿用原焊盤與PCB開窗。
- 每側一條5×50×3mm斑馬條，X2.7…7.7／68.1…73.1、Y−58…−8。
- 上蓋兩條平底壓腳**3.2×50mm**，每條接觸面160mm²，底面Z4.3。

| 剖面基準 | 自由落座 | 名義閉蓋 |
|---|---:|---:|
| PCB背面 | −1.6 | −1.6 |
| 完成焊盤頂面／斑馬條底面 | 0 | 0 |
| 下片玻璃底面 | 1.4 | 1.1 |
| 上片FTO接觸面／斑馬條頂面 | **3.0** | 2.7 |
| 上片玻璃頂面 | 4.6 | 4.3 |

PCB的1.6mm是總厚包絡，完成接觸銅面為Z0，35µm銅色示意層包含在包絡內。自由落座時，上片電極帶與斑馬條相接；閉合壓縮目標0.3mm／10%。**不再以舊下窗內緣限制玻璃高度。** 外殼自身閉合定位面只限制蓋的位置，不先從下方頂住玻璃。

使用者最新實物觀察是FTO離斑馬條約0.2mm。本次以此取代先前「已接觸」的判斷。CAD另檢查下片投影下方無塑膠，以及66mm上片自由狀態與兩側條各有140mm²名義接觸；此為幾何結果，尚不是新印件的實測接觸電阻。

下殼透光口61×61mm，PCB原開窗約57.918mm；54×54mm有效光路保持暢通。側壁及定位角只在玻璃外側，不做底部承托。

## 咬合與一次性裝板

保留原R18定位唇截面：舌寬1.4、高2mm、名義0.2mm配合；沒有新增強倒扣。空殼輕咬合作定位，窗口磁鐵與長壓腳負責壓合。

為把下排磁鐵收在窗口旁，PCB從後端入口裝入，上蓋本身同時關閉此入口。**這是一次性裝板路徑，不影響日常整蓋取下換玻璃。**

1. 上蓋、玻璃、斑馬條及PCB螺絲先移開。
2. 完整PCB在最終位置後方71.2mm，保持水平、Z+1mm，先降至入口高度。
3. 水平向前推71.2mm，通過下蓋定位壁及下排橋下方；到孔位後再降低1mm，PCB背面落在Z−1.6承靠上。
4. 固定PCB，再裝斑馬條與DSSC。玻璃先靠定位壁自由落在斑馬條上，再垂直蓋上整片上蓋。

{'電容版兩條底部避空槽延伸至後端，以容納已焊好電容的裝板路徑。前兩顆PCB螺絲M3×8、後兩顆M3×14，均低頭（頭徑≤5.5、高≤2mm）；後螺帽從底面凹槽放入，固定後不突出殼底。' if not raw else '普通版四顆PCB螺絲均M3×6低頭（頭徑≤5.5、高≤2mm），搭配M3螺帽。'}

{'K1維持B.Cu正確旋轉與八腳位置；局部底面Z−8.2、底厚1.4mm，名義淨空'+format(qa['assembly'].get('K1_clearance_mm',0),'.2f')+'mm。' if not raw else ''}
USB-C金屬面至U腔內端面0.58mm，已保留接點突出與上蓋拆卸空間。一體按鈕功能區與R16來源相同。

## Blender燈光與材質

- Cycles、三盞柔光、完整模型攝影機與窗口近照攝影機。
- SLA殼：半透明霧面樹脂、IOR1.49、表面粗糙度、微細表面紋理及體積吸收／散射；使用CAD真實厚度，沒有改幾何的修飾器。
- 玻璃、橡膠、金屬磁鐵／螺絲、PCB及電子元件分材質；材質與燈光全內嵌。
- Frame1閉合、30整蓋取下及玻璃自由回彈、60玻璃移出。預設66mm上片；切換70mm時隱藏`DSSC_upper_glass_66`、顯示`Alternative_glass`集合內的70mm上片。
- 材質是SLA外觀示意，不是樹脂透光率實測。

## 檢查與來源

- 兩件皆單一有效CAD實體；外殼／硬體／電子件靜態無體積相交。
- 66／70mm玻璃共54組XY偏移與壓合高度案例，整蓋抬起與垂直放片案例通過。
- 三段PCB裝板路徑，以每個實體的保守掃掠包絡檢查整段平移；跨板面的THT幾何另作精確切分，沒有以稀疏姿態代替連續路徑。
- 厚度法線取樣：下蓋{qa['thickness']['parts']['Lower_shell']['samples']}、上蓋{qa['thickness']['parts']['Upper_cover']['samples']}點，均未出現低於1mm的候選；取樣不是全域最薄值證明。
- STL封閉、無非流形／自相交、體積差<0.1%；STEP重讀體積差為0，ZIP CRC與macOS原生解壓通過；Blender獨立重開並核對CAD雜湊。
- PCB快照SHA256：`{data['PCB_sha256']}`。本輪未修改KiCad原檔。
- 模組採後續R6／R18高度版本：e-paper最高11.5、ESP32最高9mm，證據存於`sources/module_height_history.md`；早期KiCad外觀檔的12／13mm命名屬較早版本。
- {'保守元件包絡：'+', '.join(proxies)+'；其餘按標準STEP或既有詳細模組BRep。' if proxies else '元件使用標準STEP與既有詳細模組BRep。'}

## 重建工具

使用FreeCAD附帶Python，依序執行`tools/build.py`、`tools/check.py`、`tools/check_board.py`、`tools/thickness.py`、`tools/export.py`；再用Blender背景模式執行`tools/blender.py`，重新開啟blend以同腳本加`-- --verify`檢查，最後以FreeCAD Python執行`tools/release.py`。

本地來源足以重建，不依賴R18或另一個R19資料夾。`--bootstrap`只供重新擷取工作區來源。尺寸記錄在`parameters.json`，主要幾何構造在`build.py`。
'''
(ROOT/'README.md').write_text(text)
files=[ROOT/(name+'.FCStd'),ROOT/(name+'.blend'),ROOT/(name+'_STL.zip'),ROOT/'README.md']
write('qa/deliverables.json',{'pass':True,'design_revision':c['design_revision'],'live_PCB_matches_snapshot':live_match,
 'source_hashes_verified':True,'width_mm':84,'magnet_layout':'four pairs at each window end',
 'FTO_free_contacts_both_zebras':True,'no_under_glass_support':True,'continuous_PCB_feed_proven':True,
 'SLA_material_and_lighting':True,'physical_force_verified':False,'files':{str(p.relative_to(ROOT)):sha(p) for p in files}})
print('WINDOW_END_RELEASE_PASS',name,flush=True)
