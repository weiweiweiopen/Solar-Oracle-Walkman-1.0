"""Trim-aware finite normal-ray scan; not a global minimum certificate."""
import FreeCAD as A,Part
from build import ROOT,write
d=A.openDocument(str(ROOT/(ROOT.name+'.FCStd')))
q={'method':'3x3 trim-aware material-normal samples per face; local samples are not a mathematical global minimum.','parts':{}}
for name in ['Lower_shell','Upper_cover']:
 s=d.getObject(name).Shape;count=0;lowest=999;bad=[]
 for i,f in enumerate(s.Faces):
  u0,u1,v0,v1=f.ParameterRange
  for fu in [.2,.5,.8]:
   for fv in [.2,.5,.8]:
    u=u0+(u1-u0)*fu;v=v0+(v1-v0)*fv;p=f.valueAt(u,v)
    if not f.isInside(p,1e-6,True):continue
    n=f.normalAt(u,v)
    if n.Length<1e-8:continue
    n.normalize()
    if not s.isInside(p-n*.002,1e-6,False):
     n=-n
     if not s.isInside(p-n*.002,1e-6,False):continue
    seg=Part.makeLine(p-n*.00001,p-n*60).common(s)
    es=[e for e in seg.Edges if min((vv.Point-p).Length for vv in e.Vertexes)<.001]
    if not es:continue
    t=es[0].Length+.00001;count+=1;lowest=min(lowest,t)
    if t<.9999:bad.append({'face':i,'point':list(p),'thickness_mm':t})
 q['parts'][name]={'samples':count,'sample_min_mm':lowest,'below_1mm_candidates':bad}
 print('THICKNESS',name,count,lowest,len(bad),flush=True)
q['pass']=not any(r['below_1mm_candidates'] for r in q['parts'].values())
write('qa/thickness.json',q)
