"""Export the two verified CAD parts, embedded Blender mesh input, and vendor-only ZIP."""
import hashlib,json,subprocess,tempfile,zipfile
from pathlib import Path
import FreeCAD as A,Part,Mesh,MeshPart
from build import ROOT,read,write,sha,V
for p in ['assembly','PCB_installation','thickness']:assert read('qa/'+p+'.json')['pass'],p
d=A.openDocument(str(ROOT/(ROOT.name+'.FCStd')))
for name in ['STL_mm','STEP','cache/assembly_mesh']:(ROOT/name).mkdir(parents=True,exist_ok=True)
report={'parts':{},'units':'mm','scale':'1:1','printed_count':2,'CAD_sha256':sha(ROOT/(ROOT.name+'.FCStd'))}
for n in ['Lower_shell','Upper_cover']:
 s=d.getObject(n).Shape
 step=ROOT/'STEP'/(n+'.step');s.exportStep(str(step));r=Part.read(str(step))
 diff=s.cut(r).Volume+r.cut(s).Volume
 assert r.isValid() and len(r.Solids)==1 and diff<1e-5
 t=s.copy()
 if n=='Upper_cover':t.rotate(V(),V(1,0,0),180)
 vs,_=t.tessellate(.025);shift=[-min(v[i] for v in vs) for i in range(3)];t.translate(V(*shift))
 m=MeshPart.meshFromShape(Shape=t,LinearDeflection=.025,AngularDeflection=.1,Relative=False)
 m.translate(-m.BoundBox.XMin,-m.BoundBox.YMin,-m.BoundBox.ZMin)
 path=ROOT/'STL_mm'/(ROOT.name+'_'+n+'.stl')
 with path.open('w',encoding='ascii',newline='\n') as f:
  f.write('solid '+ROOT.name+'_'+n+'\n')
  for facet in m.Facets:
   f.write(' facet normal '+' '.join(format(c,'.17g') for c in facet.Normal)+'\n  outer loop\n')
   for p in facet.Points:f.write('   vertex '+' '.join(format(c,'.17g') for c in p)+'\n')
   f.write('  endloop\n endfacet\n')
  f.write('endsolid '+ROOT.name+'_'+n+'\n')
 mm=Mesh.Mesh(str(path))
 rec={'closed':mm.isSolid(),'nonmanifold':mm.hasNonManifolds(),'self_intersection':mm.hasSelfIntersections(),
  'facets':mm.CountFacets,'CAD_volume_mm3':s.Volume,'STL_volume_mm3':mm.Volume,'STEP_difference_mm3':diff,
  'sha256':sha(path),'print_rotation_x_deg':180 if n=='Upper_cover' else 0,'translation_mm':shift}
 assert rec['closed'] and not rec['nonmanifold'] and not rec['self_intersection']
 assert abs(mm.Volume-s.Volume)/s.Volume<.001
 report['parts'][n]=rec
Part.export([d.getObject(n) for n in ['Lower_shell','Upper_cover']],str(ROOT/'STEP'/(ROOT.name+'_PRINTED_ASSEMBLY.step')))
manifest=[]
for ob in d.Objects:
 if not hasattr(ob,'Category'):continue
 s=ob.Shape;m=MeshPart.meshFromShape(Shape=s,LinearDeflection=.025,AngularDeflection=.1,Relative=False)
 verts,faces=m.Topology
 write('cache/assembly_mesh/'+ob.Name+'.json',{'vertices':[list(v) for v in verts],'faces':[list(f) for f in faces]})
 manifest.append({'name':ob.Name,'category':ob.Category,'CAD_volume_mm3':s.Volume,'evidence':ob.Evidence})
write('cache/assembly_mesh/manifest.json',manifest)
zpath=ROOT/(ROOT.name+'_STL.zip')
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted((ROOT/'STL_mm').glob('*.stl')):z.write(p,p.name)
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and len(z.infolist())==2
 assert all('/' not in n and n.isascii() and n.endswith('.stl') for n in z.namelist())
 names=z.namelist()
with tempfile.TemporaryDirectory(dir=ROOT/'cache') as td:
 with zipfile.ZipFile(zpath) as archive: archive.extractall(td)
 for name in names:
  p=Path(td)/name;assert sha(p)==sha(ROOT/'STL_mm'/name)
  assert Mesh.Mesh(str(p)).isSolid()
report.update({'pass':True,'ZIP_sha256':sha(zpath),'ZIP_files':names,'ZIP_CRC_pass':True,'stdlib_zip_extract_pass':True})
write('qa/export.json',report)
print('EXPORT_PASS',ROOT.name,report['parts'],flush=True)
