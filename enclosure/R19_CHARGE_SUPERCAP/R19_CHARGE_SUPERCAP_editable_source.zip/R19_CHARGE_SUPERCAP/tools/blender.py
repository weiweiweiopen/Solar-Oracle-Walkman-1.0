"""Embedded engineering geometry with a lit translucent-SLA studio scene."""
import bpy,bmesh,json,hashlib,sys,tempfile,math
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads((ROOT/p).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):(ROOT/p).write_text(json.dumps(d,indent=2,ensure_ascii=False))
S=bpy.context.scene
if '--verify' in sys.argv:
 assert Path(bpy.data.filepath).resolve()==(ROOT/(ROOT.name+'.blend')).resolve()
 assert S['CAD_sha256']==sha(ROOT/(ROOT.name+'.FCStd')) and len(bpy.data.libraries)==0
 assert S.unit_settings.system=='METRIC' and abs(S.unit_settings.scale_length-.001)<1e-9
 for fr in [1,30,60]:
  S.frame_set(fr);bpy.context.view_layer.update()
  for i in range(8):assert abs(bpy.data.objects['Magnet_upper_'+str(i)].matrix_world.translation.z-bpy.data.objects['Upper_cover'].matrix_world.translation.z)<1e-6
 assert len([o for o in bpy.data.objects if o.get('Category')=='Printed'])==2
 assert S.render.engine=='CYCLES'
 assert len([o for o in bpy.data.objects if o.type=='LIGHT'])>=3
 resin=bpy.data.materials['SLA_frosted_translucent'];bs=resin.node_tree.nodes.get('Principled BSDF')
 assert bs.inputs['Transmission Weight'].default_value>.5
 assert .15<bs.inputs['Roughness'].default_value<.4
 assert all(bpy.data.objects[n].data.materials[0]==resin for n in ['Lower_shell','Upper_cover'])
 S.frame_set(1)
 write('qa/blender_saved.json',{'pass':True,'independent_reopen':True,'CAD_hash_matches':True,'no_external_libraries':True,'two_printed_parts':True,'SLA_translucent_material_verified':True,'studio_lights_verified':True})
 print('BLENDER_REOPEN_PASS',ROOT.name,flush=True);raise SystemExit(0)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
S.unit_settings.system='METRIC';S.unit_settings.scale_length=.001;S.unit_settings.length_unit='MILLIMETERS'
S.render.engine='CYCLES';S.cycles.samples=64;S.cycles.preview_samples=12;S.cycles.use_denoising=True
S.cycles.max_bounces=12;S.cycles.transmission_bounces=8;S.cycles.volume_bounces=3
S.cycles.caustics_reflective=False;S.cycles.caustics_refractive=False
S.render.resolution_x=1400;S.render.resolution_y=1200;S.render.resolution_percentage=100
S.view_settings.view_transform='AgX';S.view_settings.look='AgX - Medium High Contrast'
S.render.image_settings.file_format='PNG';S.render.film_transparent=False

def material(name,color,rough=.4,metal=0,transmission=0,ior=1.5):
 m=bpy.data.materials.new(name);m.use_nodes=True;m.diffuse_color=(*color,1)
 bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1)
 bs.inputs['Roughness'].default_value=rough;bs.inputs['Metallic'].default_value=metal
 bs.inputs['Transmission Weight'].default_value=transmission;bs.inputs['IOR'].default_value=ior
 return m
resin=material('SLA_frosted_translucent',(.86,.90,.88),.21,0,.92,1.49)
nt=resin.node_tree;bs=nt.nodes.get('Principled BSDF');bs.inputs['Coat Weight'].default_value=.12
bs.inputs['Coat Roughness'].default_value=.23;bs.inputs['Subsurface Weight'].default_value=0
bs.inputs['Subsurface Radius'].default_value=(.35,.28,.22);bs.inputs['Subsurface Scale'].default_value=1
tex=nt.nodes.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=6;tex.inputs['Detail'].default_value=2
bump=nt.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.08;bump.inputs['Distance'].default_value=.008
nt.links.new(tex.outputs['Fac'],bump.inputs['Height']);nt.links.new(bump.outputs['Normal'],bs.inputs['Normal'])
absorb=nt.nodes.new('ShaderNodeVolumeAbsorption');absorb.inputs['Color'].default_value=(.83,.91,.88,1);absorb.inputs['Density'].default_value=.006
scatter=nt.nodes.new('ShaderNodeVolumeScatter');scatter.inputs['Color'].default_value=(.95,.97,.96,1);scatter.inputs['Density'].default_value=.012;scatter.inputs['Anisotropy'].default_value=.2
add=nt.nodes.new('ShaderNodeAddShader');nt.links.new(absorb.outputs[0],add.inputs[0]);nt.links.new(scatter.outputs[0],add.inputs[1])
nt.links.new(add.outputs[0],nt.nodes.get('Material Output').inputs['Volume'])
resin['process']='SLA UV resin, frosted semi-transparent appearance; actual CAD thickness, no geometry modifiers'
resin['optical_note']='Appearance settings only, not measured resin optical constants. Coordinates are millimetres.'
metal=material('Nickel_and_fasteners',(.58,.62,.65),.22,.92)
pcb=material('Green_soldermask',(.025,.15,.083),.36)
rubber=material('Zebra_elastomer',(.035,.04,.045),.72)
plastic=material('IC_and_headers',(.024,.028,.032),.48)
ceramic=material('Ceramic_capacitors',(.39,.26,.13),.43)
copper=material('DSSC_contact_copper',(.66,.37,.09),.23,.9)
glass=material('DSSC_FTO_glass',(.76,.88,.85),.065,0,.96,1.52)
activeglass=material('DSSC_amber_glass',(.61,.29,.085),.10,0,.86,1.52)
white=material('Epaper_display',(.77,.79,.75),.69)
screen=material('Epaper_panel',(.13,.145,.14),.28)
floor_mat=material('Studio_floor',(.19,.22,.25),.62)
cols={};obs={};qa={}
palette={'Printed':(.73,.84,.82,1),'Electronics':(.07,.30,.19,1),'Glass':(.61,.30,.13,1),
 'Alternative_glass':(.36,.53,.62,1),'Zebra':(.08,.09,.11,1),'Hardware':(.5,.5,.53,1),'Lower_magnets':(.4,.5,.66,1),'Upper_magnets':(.4,.5,.66,1)}
for rec in read('cache/assembly_mesh/manifest.json'):
 n=rec['name'];cat=rec['category'];data=read('cache/assembly_mesh/'+n+'.json')
 me=bpy.data.meshes.new(n);me.from_pydata(data['vertices'],[],data['faces']);me.update()
 ob=bpy.data.objects.new(n,me);obs[n]=ob
 if cat not in cols:cols[cat]=bpy.data.collections.new(cat);S.collection.children.link(cols[cat])
 cols[cat].objects.link(ob);ob.color=palette[cat];ob['Category']=cat;ob['Evidence']=rec['evidence']
 for p in me.polygons:p.use_smooth=True
 me.set_sharp_from_angle(angle=math.radians(30))
 mat=resin if cat=='Printed' else metal if cat in ['Hardware','Lower_magnets','Upper_magnets'] else rubber if cat=='Zebra' else glass if 'glass' in n else pcb if n=='Carrier_board' or n.startswith('ESP32') else copper if n.startswith('DSSC_pad') else ceramic if n.startswith('PCB_C') else plastic
 if n.startswith('DSSC_upper_glass'):mat=activeglass
 ob.data.materials.append(mat)
 if n=='Epaper_module':
  ob.data.materials.clear()
  for m in [pcb,plastic,metal,screen,white]:ob.data.materials.append(m)
  for p in me.polygons:
   z=p.center.z;p.material_index=4 if z>11.485 else 3 if z>10.47 else 0 if z>8.87 else 2 if z<2 else 1
 if n.startswith('ESP32'):
  ob.data.materials.append(metal);ob.data.materials.append(plastic)
  usbface=62.57 if n=='ESP32_raw_module' else 61.17
  for p in me.polygons:
   c=p.center
   p.material_index=1 if c.x>usbface-8 and -121.1<c.y<-111.5 and c.z>4.7 else 2 if c.z>4.5 else 0
 if n.startswith(('PCB_R','PCB_C')):
  ob.data.materials.append(metal)
  xs=[v.co.x for v in me.vertices];ys=[v.co.y for v in me.vertices]
  axis=0 if max(xs)-min(xs)>max(ys)-min(ys) else 1
  lo,hi=(min(xs),max(xs)) if axis==0 else (min(ys),max(ys))
  for p in me.polygons:
   if p.center[axis]<lo+.4 or p.center[axis]>hi-.4:p.material_index=1
 if n=='Upper_cover':ob.color=(.34,.66,.59,1)
 if n=='Epaper_module':ob.color=(.78,.81,.78,1)
 if n.startswith('ESP32'):ob.color=(.11,.25,.36,1)
 if n.startswith('Supercap'):ob.color=(.14,.20,.31,1)
 if n.startswith('Envelope'):ob.color=(.9,.4,.1,1)
 if cat=='Alternative_glass':ob.hide_set(True);ob.hide_render=True
 if n=='Upper_cover' or cat in ['Glass','Alternative_glass','Zebra']:
  for fr,lift,glift in [(1,0,0),(30,35,.3),(60,50,20.3)]:
   ob.location=(0,0,lift if n=='Upper_cover' else glift if cat in ['Glass','Alternative_glass'] else 0)
   ob.scale=(1,1,3/2.7 if cat=='Zebra' and fr>1 else 1)
   ob.keyframe_insert(data_path='location',frame=fr);ob.keyframe_insert(data_path='scale',frame=fr)
  for fc in ob.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='LINEAR'
 if cat=='Printed':
  bm=bmesh.new();bm.from_mesh(me);bad=sum(not e.is_manifold for e in bm.edges);volume=abs(bm.calc_volume(signed=True));bm.free()
  assert bad==0 and abs(volume-rec['CAD_volume_mm3'])/rec['CAD_volume_mm3']<.001
  qa[n]={'nonmanifold_edges':bad,'mesh_volume_mm3':volume,'CAD_volume_mm3':rec['CAD_volume_mm3']}
for n,o in obs.items():
 if o['Category']=='Upper_magnets':o.parent=obs['Upper_cover']
S.frame_start=1;S.frame_end=60;S.frame_set(1)
presentation=bpy.data.collections.new('Studio_lighting_and_cameras');S.collection.children.link(presentation)
def link(ob):presentation.objects.link(ob);ob['Category']='Presentation';return ob
def aim(ob,target):ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler()
def area(name,location,target,power,size):
 dat=bpy.data.lights.new(name,'AREA');dat.energy=power;dat.shape='DISK';dat.size=size
 ob=link(bpy.data.objects.new(name,dat));ob.location=location;aim(ob,target)
area('Key_softbox',(-110,25,190),(38,-55,0),650000,150)
area('Fill_softbox',(170,-15,100),(38,-60,0),350000,140)
area('Rim_softbox',(20,-220,135),(38,-65,5),950000,110)
world=bpy.data.worlds.new('Studio_world');world.use_nodes=True
world.node_tree.nodes['Background'].inputs['Color'].default_value=(.66,.72,.78,1);world.node_tree.nodes['Background'].inputs['Strength'].default_value=.32;S.world=world
for name,loc,target,scale in [('Assembly_camera',(205,105,180),(38,-63,1),210),('Window_contact_camera',(150,-35,65),(37.9,-33,3),112)]:
 dat=bpy.data.cameras.new(name);dat.type='ORTHO';dat.ortho_scale=scale;dat.clip_start=.1;dat.clip_end=5000
 ob=link(bpy.data.objects.new(name,dat));ob.location=loc;aim(ob,target)
 if name=='Assembly_camera':S.camera=ob
bottom=read('parameters.json')['main_floor_z'] if ROOT.name.endswith('_RAW') else -14.6
me=bpy.data.meshes.new('Studio_floor');me.from_pydata([(-1000,-1000,bottom-.2),(1000,-1000,bottom-.2),(1000,1000,bottom-.2),(-1000,1000,bottom-.2)],[],[(0,1,2,3)])
ob=link(bpy.data.objects.new('Studio_floor',me));me.materials.append(floor_mat)
target=Vector((39,-64,0));rot=(target-Vector((220,120,180))).to_track_quat('-Z','Y')
for screen in bpy.data.screens:
 for ar in screen.areas:
  if ar.type=='VIEW_3D':
   sp=ar.spaces.active;sp.region_3d.view_location=target;sp.region_3d.view_distance=230;sp.region_3d.view_rotation=rot;sp.region_3d.view_perspective='PERSP'
   sp.shading.type='MATERIAL';sp.shading.use_scene_lights=True;sp.shading.use_scene_world=True;sp.clip_start=.1;sp.clip_end=10000
S['CAD_sha256']=sha(ROOT/(ROOT.name+'.FCStd'));S['revision']=ROOT.name
S['poses']='1 closed with 66mm upper glass;30 whole lid removed;60 glass removed. Alternative 70mm glass hidden in its own collection.'
S['note']='Two-piece window-end magnetic prototype. Lit translucent-SLA studio; all CAD geometry embedded in mm. Optical and contact force values are not measurements.'
bpy.ops.object.select_all(action='DESELECT');obs['Lower_shell'].select_set(True);bpy.context.view_layer.objects.active=obs['Lower_shell']
write('qa/blender.json',{'pass':True,'parts':qa,'studio_lights':3,'SLA_translucent_material':True,'CAD_geometry_modifiers':0,'CAD_sha256':S['CAD_sha256']})
with tempfile.TemporaryDirectory(dir=ROOT/'cache') as td:
 p=Path(td)/(ROOT.name+'.blend');bpy.ops.wm.save_as_mainfile(filepath=str(p));p.replace(ROOT/p.name)
print('BLENDER_PASS',ROOT.name,len(obs),flush=True)
if '--preview' in sys.argv:
 (ROOT/'review').mkdir(exist_ok=True)
 S.render.resolution_x=800;S.render.resolution_y=700;S.cycles.samples=24
 S.render.filepath=str(ROOT/'review/assembly_preview.png');bpy.ops.render.render(write_still=True)
 print('SLA_PREVIEW_SAVED',S.render.filepath,flush=True)
