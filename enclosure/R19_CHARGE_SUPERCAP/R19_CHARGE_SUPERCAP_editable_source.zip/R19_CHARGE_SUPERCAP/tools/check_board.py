"""Continuous, conservative per-solid swept boxes for the prescribed PCB feed path."""
import FreeCAD as A
from build import ROOT,read,write,box,moved,overlap
doc=A.openDocument(str(ROOT/(ROOT.name+'.FCStd')));cfg=read('parameters.json')
lower=doc.getObject('Lower_shell').Shape
elec={o.Name:o.Shape for o in doc.Objects if hasattr(o,'Category') and o.Category=='Electronics'}
offset=cfg['PCB_install_rear_offset'];lift=cfg['PCB_install_lift_mm']
stages=[('lower_behind_bridge',[-offset,35],[-offset,lift]),('slide_into_case',[-offset,lift],[0,lift]),('seat_1p6mm_PCB',[0,lift],[0,0])]
motion=[];count=0
for kind,start,end in stages:
 bad={}
 for n,s in elec.items():
  pieces=[]
  for solid in s.Solids:
   b=solid.BoundBox
   if b.ZMin < -1e-6 and b.ZMax > 1e-6:
    # Separate below-board terminals from the much wider body. Both exact pieces
    # remain enclosed; a casing bbox must not turn a narrow THT leg into a plate.
    for z0,z1 in [(b.ZMin-.01,0),(0,b.ZMax+.01)]:
     pieces+=solid.common(box(b.XMin-.01,b.YMin-.01,z0,b.XLength+.02,b.YLength+.02,z1-z0)).Solids
   else:pieces.append(solid)
  for i,solid in enumerate(pieces):
   b=solid.BoundBox
   y0=b.YMin+min(start[0],end[0]);y1=b.YMax+max(start[0],end[0])
   z0=b.ZMin+min(start[1],end[1]);z1=b.ZMax+max(start[1],end[1])
   sweep=box(b.XMin,y0,z0,b.XLength,y1-y0,z1-z0)
   vol=overlap(sweep,lower);count+=1
   if vol>1e-5:bad[n+'_'+str(i)]=vol
  if n in ['Carrier_board','Epaper_module','PCB_JP201']:print('SWEEP_CHECKED',kind,n,flush=True)
 rec={'kind':kind,'start_yz':start,'end_yz':end,'conservative_sweep_hits':bad};motion.append(rec)
 print('PCB_STAGE',rec,flush=True)
q={'pass':not any(r['conservative_sweep_hits'] for r in motion),'stages':motion,'swept_solid_envelopes':count,
 'continuous_motion_proven':not any(r['conservative_sweep_hits'] for r in motion),
 'method':'No rotation: the swept axis-aligned box of EACH source solid encloses its entire translation. Zero intersection of all boxes is a conservative continuous-path proof. Positive candidates are failures, not silently waived.'}
write('qa/PCB_installation.json',q);print('PCB_INSTALLATION_PASS',q['pass'],flush=True)
