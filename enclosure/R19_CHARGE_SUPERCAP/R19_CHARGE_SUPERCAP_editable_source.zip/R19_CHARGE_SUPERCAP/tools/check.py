"""Mechanical assembly checks. A passing model is not a measured force test."""
import itertools,json,sys
import FreeCAD as A
import Part
from build import ROOT,read,write,box,cyl,moved,overlap,bounds,shape_file,V

doc=A.openDocument(str(ROOT/(ROOT.name+'.FCStd')))
cfg=read('parameters.json');parts={n:doc.getObject(n).Shape for n in ['Lower_shell','Upper_cover']}
refs={o.Name:(o.Shape,o.Category) for o in doc.Objects if hasattr(o,'Category') and o.Category!='Printed'}
def hits(s,targets):
 result={}
 for n,t in targets.items():
  vol=overlap(s,t)
  if vol>1e-5:result[n]=vol
 return result

q={'part_overlap_mm3':overlap(*parts.values()),'reference_clashes':{},'lid_motion':[],
 'glass_cases':[],'glass_placement_sweeps':[],'contact_paths':{},'checks':{},'trust_summary':{
 'confidence':'deterministic CAD geometry, mixed physical evidence','sources':['current PCB snapshot','standard STEP','frozen module BRep','user glass/PCB/zebra dimensions'],
 'limits':['No magnet grade/force or elastomer force curve','Envelope substitutes: '+', '.join(n for n in refs if n.startswith('Envelope_')),'No printed prototype/flatness or electrical resistance test'],
 'physical_pressure_verified':False}}
for pn,s in parts.items():
 bad=hits(s,{n:t for n,(t,c) in refs.items() if c!='Alternative_glass'})
 if bad:q['reference_clashes'][pn]=bad
print('STATIC',q['part_overlap_mm3'],q['reference_clashes'],flush=True)
fixed={n:s for n,(s,c) in refs.items() if c in ['Electronics','Hardware','Lower_magnets']}
fixed['Lower_shell']=parts['Lower_shell']
for dz in [0,.1,.3,.5,1,2,3,5,8,12,20,35]:
 bad=hits(moved(parts['Upper_cover'],z=dz),fixed)
 for w in [66,70]:
  g=moved(refs['DSSC_upper_glass_'+str(w)][0],z=min(dz,.3))
  vv=overlap(moved(parts['Upper_cover'],z=dz),g)
  if vv>1e-5:bad['upper_glass_'+str(w)]=vv
 q['lid_motion'].append({'lift_z':dz,'hits':bad})
for w in [66,70]:
 for dx,dy,dz in itertools.product([-.2,0,.2],[-.2,0,.2],[0,.15,.3]):
  gs=[moved(refs[n][0],x=dx,y=dy,z=dz) for n in ['DSSC_upper_glass_'+str(w),'DSSC_lower_glass']]
  cover=moved(parts['Upper_cover'],z=dz)
  obstacles={**fixed,'Upper_cover':cover}
  bad={str(i):h for i,g in enumerate(gs) if (h:=hits(g,obstacles))}
  q['glass_cases'].append({'width':w,'offset':[dx,dy,dz],'hits':bad})
 for name in ['DSSC_upper_glass_'+str(w),'DSSC_lower_glass']:
  b=refs[name][0].BoundBox
  sweep=box(b.XMin,b.YMin,b.ZMin+.3,b.XLength,b.YLength,35+b.ZLength)
  q['glass_placement_sweeps'].append({'name':name,'hits':hits(sweep,fixed)})
 # Each vertical electrical path must be shared by PCB pad, zebra and exposed upper electrode.
 cx=cfg['glass_centre_x'];upper=refs['DSSC_upper_glass_'+str(w)][0]
 q['contact_paths'][str(w)]=[]
 for side,zebra,pad,ex0,ex1 in [('left','Zebra_0','DSSC_pad_2',cx-w/2,cx-30),('right','Zebra_1','DSSC_pad_1',cx+30,cx+w/2)]:
  zb=refs[zebra][0].BoundBox;pb=refs[pad][0].BoundBox
  lo=max(zb.XMin,pb.XMin,ex0);hi=min(zb.XMax,pb.XMax,ex1)
  q['contact_paths'][str(w)].append({'side':side,'common_vertical_width_mm':hi-lo,'length_mm':50,'area_mm2':(hi-lo)*50})
opt=box(10.9,-60,-20,54,54,40)
q['optical_obstructions']=hits(opt,dict(parts,Carrier_board=refs['Carrier_board'][0]))
q['USB_corridor']=hits(box(read('qa/build.json')['mapping']['USB_shell_face_x'],read('qa/build.json')['mapping']['USB_centre_y']-5.2,3.77,50,10.4,6.2),parts)
q['button_source_difference_mm3']=overlap(box(9.5,-117.8,1.7,7.3,19.6,13.4),parts['Upper_cover'].cut(shape_file('sources/R16_button_functional_region.brep')))
q['pressure_contact_areas_mm2']=[]
for x in [5.2,67.4]:
 face=Part.Face(Part.makePolygon([V(x,-58,4.3),V(x+3.2,-58,4.3),V(x+3.2,-8,4.3),V(x,-8,4.3),V(x,-58,4.3)]))
 q['pressure_contact_areas_mm2'].append(face.common(parts['Upper_cover']).common(refs['DSSC_upper_glass_66'][0]).Area)
q['under_lower_glass_obstructions']=hits(box(7.9,-63,0,60,60,1.4),parts)
q['free_FTO_contact_area_mm2']=[]
for x in [2.7,68.1]:
 f=Part.Face(Part.makePolygon([V(x,-58,3),V(x+5,-58,3),V(x+5,-8,3),V(x,-8,3),V(x,-58,3)]))
 q['free_FTO_contact_area_mm2'].append(f.common(moved(refs['DSSC_upper_glass_66'][0],z=.3)).Area)
q['magnet_face_gaps_mm']=[refs['Magnet_upper_'+str(i)][0].BoundBox.ZMin-refs['Magnet_lower_'+str(i)][0].BoundBox.ZMax for i in range(8)]
q['checks']['no_glass_shelf']=not q['under_lower_glass_obstructions']
q['checks']['free_FTO_contacts_both_zebras']=all(abs(a-140)<1e-5 for a in q['free_FTO_contact_area_mm2'])
q['checks']['same_front_rear_magnet_gap']=all(abs(v-2.05)<1e-6 for v in q['magnet_face_gaps_mm'])
q['checks']['two_single_solids']=all(s.isValid() and len(s.Solids)==1 for s in parts.values())
q['checks']['sixteen_magnets']=sum(c in ['Lower_magnets','Upper_magnets'] for s,c in refs.values())==16
q['checks']['no_hatch']=not any('hatch' in n.lower() for n in refs)
q['checks']['nominal_compression_10percent']=abs((3-2.7)/3-.1)<1e-8
q['checks']['optical_corridor_clear']=not q['optical_obstructions']
q['checks']['USB_corridor_clear']=not q['USB_corridor']
q['checks']['button_unchanged']=q['button_source_difference_mm3']<1e-5
q['checks']['full_pressure_feet']=all(abs(a-160)<1e-5 for a in q['pressure_contact_areas_mm2'])
if cfg['variant']!='raw':q['K1_clearance_mm']=refs['K1_relay'][0].distToShape(parts['Lower_shell'])[0]
q['pass']=q['part_overlap_mm3']<1e-5 and not q['reference_clashes'] and not any(r['hits'] for r in q['lid_motion']+q['glass_cases']+q['glass_placement_sweeps']) and all(q['checks'].values())
write('qa/assembly.json',q)
print('ASSEMBLY_PASS',q['pass'],'checks',q['checks'],'contacts',q['contact_paths'],'feet',q['pressure_contact_areas_mm2'],flush=True)
print('FAILED_MOTIONS',[r for r in q['lid_motion']+q['glass_cases']+q['glass_placement_sweeps'] if r['hits']],flush=True)
if '--board' in sys.argv:
 import subprocess
 subprocess.run([sys.executable,'-B',str(ROOT/'tools/check_board.py')],check=True)
